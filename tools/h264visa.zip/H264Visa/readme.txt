H264Visa Setup Package.

General Info
==============
Please access h264visa webpage at:
http://www.h264visa.com

File List
==============
 - H264Visa.exe, the H.264/AVC baseline profile analyzer
 - H264Visa.intermediate.manifest, used for distribution.
 - H264Visa.pdf, the user manual.
 - H264Visa_License.txt, the product license.
 - readme.txt, the file you are reading now.

Install 
==============
Please run setup.exe and follow the instructions

Run
==============
Please run H264Visa.exe

Uninstall
==============
Please run uninstall from the [startmenu]->[h264visa]->[uninstall], or
uninstall H264Visa from Add/Remove programs from control panel.

Bug Report & Support
====================
Please send mail to:
support@h264visa.com
